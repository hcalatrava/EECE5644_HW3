% Question 1 (50%)
%% Init code
clear all
close all
clc
rng('default')

%% Init variables
class_priors = [0.6, 0.4];

% Class 0
mu_01 = [5 0]';
mu_02 = [0 4]';
C_01 = [4 0; 0 2];
C_02 = [1 0; 0 3];
mu_0 = [mu_01 mu_02];
C_0(:, :, 1) = C_01;
C_0(:, :, 2) = C_02;

% Class 1
mu_1 = [3 2]';
C_1 = 2*eye(2);

gmm_priors = [0.5, 0.5];

%% Data generation

% % D^100_train
N = 1e2;
filename = 'D_100_train.mat';
generate_data(N, class_priors, gmm_priors, mu_0, C_0, mu_1, C_1, filename);

% D^1000_train
N = 1e3;
filename = 'D_1000_train.mat';
generate_data(N, class_priors, gmm_priors, mu_0, C_0, mu_1, C_1, filename);

% D^10000_train
N = 1e4;
filename = 'D_10000_train.mat';
generate_data(N, class_priors, gmm_priors, mu_0, C_0, mu_1, C_1, filename);

% D^20K_validate
N = 20e3;
filename = 'D_20k_validate.mat';
generate_data(N, class_priors, gmm_priors, mu_0, C_0, mu_1, C_1, filename);

%% Part 1 (10%)
close all;
% Bayes Classifier applied to D^20k_validate
input = load('D_20k_validate.mat');
samples = input.data;
labels = input.labels;

% Get the likelihood values for both classes
[likelihood_0, likelihood_1] = get_likelihoods(samples, mu_0, C_0, mu_1, C_1, gmm_priors);

% We check classification results for several values of gamma threshold
N_gamma = 1e3;
filename = 'results_part_1';
pe_min = plot_ROC_Pe(N_gamma, likelihood_0, likelihood_1, labels, samples, class_priors, filename);

%% Part 1 (find the boundary empirically)
clc
tolerance = 1e-2;
mesh_size = 1e2;
mesh_range_x = linspace(-4,12,mesh_size);
mesh_range_y = linspace(-2,8,mesh_size);
[mesh_x, mesh_y] = meshgrid(mesh_range_x, mesh_range_y);
for idx_i = linspace(1,mesh_size,mesh_size)
    for idx_j = linspace(1,mesh_size,mesh_size)
        x = mesh_x(idx_i, idx_j);
        y = mesh_y(idx_i, idx_j);
        [likelihood_0, likelihood_1] = get_likelihoods([x y]', mu_0, C_0, mu_1, C_1, gmm_priors);
        boundary(idx_i,idx_j) = (likelihood_0-likelihood_1)<tolerance;
    end
end
sum(sum(boundary))
contour(mesh_x, mesh_y,boundary)

%% Part 2 (20%) - Get Results
% Training set
filename = 'results_part_2_D_10000_train.mat' % change this 
input = load('D_10000_train.mat'); % change this to load a different training set
samples = input.data;
labels = input.labels;

% Plot data distribution
gmm_labels = input.gmm_labels;
gmm_data = samples(:,find(labels==0));
% Plot
color=lines(4);
f = figure(1);
f.Position = [100, 100, 8e2, 5e2]; clf,
subplot(1,2,1),
h = gscatter(samples(1,:)',samples(2,:)',labels', color(1:2,:));
legend(['$x|L=0 \sim \mathcal{N}(\mathbf{m}_{0}, \mathbf{C}_{0})$'], ['$x|L=1 \sim \mathcal{N}(\mathbf{m}_1, \mathbf{C}_1)$'], 'Interpreter', 'Latex')
grid on,
hold off,
subplot(1,2,2),
h = gscatter(gmm_data(1,:)',gmm_data(2,:)',gmm_labels', color(3:4,:));
legend(['$x|L=0, comp=1 \sim \mathcal{N}(\mathbf{m}_{01}, \mathbf{C}_{01})$'], ['$x|L=0, comp=2 \sim \mathcal{N}(\mathbf{m}_{02}, \mathbf{C}_{02})$'],'Interpreter', 'Latex')
grid on,
hold on

% GMM Expectation-Maximization algorithm for parameter estimation
% use fitgmdist matlab function
GMModel = fitgmdist(gmm_data',2);
% Plot GMM with estimated parameters
gmPDF = @(x,y) arrayfun(@(x0,y0) pdf(GMModel,[x0 y0]),x,y);
g = gca;
fcontour(gmPDF,[g.XLim g.YLim])
legend(['$x|L=0, comp=1 \sim \mathcal{N}(\mathbf{m}_{01}, \mathbf{C}_{01})$'], ['$x|L=0, comp=2 \sim \mathcal{N}(\mathbf{m}_{02}, \mathbf{C}_{02})$'], ['Contour GMM obtained with fitgmdist'],'Interpreter', 'Latex')
hold off,

% Class priors estimation (with the labels)
class_priors(2) = sum(labels)/size(samples,2);
class_priors(1) = 1 - class_priors(2);

% MLE for parameter estimation of Gaussian (class 1)
samples_class_1 = samples(:, find(labels==1));
mu_1_MLE = mean(samples_class_1, 2);
C_1_MLE = (samples_class_1-mu_1_MLE)*(samples_class_1-mu_1_MLE)'/size(samples_class_1,2);

% Parameter estimation of GMM has been performed with the fitgmdist MATLAB
% function, which uses k-means for clustering and iterates the
% Expectation-Maximization (EM) algorithm
% GMM weights (or priors)
gmm_priors = GMModel.ComponentProportion;
mu_01_EM = GMModel.mu(:,1);
mu_02_EM = GMModel.mu(:,2);
C_0_EM = GMModel.Sigma;

% Validation
input = load('D_20K_validate.mat'); % change this to load a different training set
samples_validation = input.data;
labels_validation = input.labels;

% Now that we have estimated the data with the MLE and EM algorithm, we can
% build the likelihood ratio considering these parameters
% Get the likelihood values for both classes
[likelihood_0, likelihood_1] = get_likelihoods(samples_validation, GMModel.mu, GMModel.Sigma, mu_1, C_1, gmm_priors);

% We check classification results for several values of gamma threshold
N_gamma = 1e3;
pe_min = plot_ROC_Pe(N_gamma, likelihood_0, likelihood_1, labels_validation, samples_validation, class_priors, filename);

%% Part 2 - Plot Final Results (containing 3 cases)
results_D_100 = load('results_part_2_D_100_train.mat');
results_D_1000 = load('results_part_2_D_1000_train.mat');
results_D_10000 = load('results_part_2_D_10000_train.mat');

% Plot ROC curve
f = figure(1);
f.Position = [100, 100, 8e2, 5e2]; clf,
plot(results_D_100.fpr, results_D_100.tpr)
hold on,
plot(results_D_100.fpr(results_D_100.index_min_p_error), results_D_100.tpr(results_D_100.index_min_p_error), 'x', 'MarkerSize',10, 'LineWidth',5),
hold on,
plot(results_D_100.fpr(results_D_100.index_gamma_operating_point), results_D_100.tpr(results_D_100.index_gamma_operating_point), '.', 'MarkerSize',10, 'LineWidth',5),
hold on,
plot(results_D_1000.fpr, results_D_1000.tpr)
hold on,
plot(results_D_1000.fpr(results_D_1000.index_min_p_error), results_D_1000.tpr(results_D_1000.index_min_p_error), 'x', 'MarkerSize',10, 'LineWidth',5),
hold on,
plot(results_D_1000.fpr(results_D_1000.index_gamma_operating_point), results_D_1000.tpr(results_D_1000.index_gamma_operating_point), '.', 'MarkerSize',10, 'LineWidth',5),
hold on,
plot(results_D_10000.fpr, results_D_10000.tpr)
hold on,
plot(results_D_10000.fpr(results_D_10000.index_min_p_error), results_D_10000.tpr(results_D_10000.index_min_p_error), 'x', 'MarkerSize',10, 'LineWidth',5),
hold on,
plot(results_D_10000.fpr(results_D_10000.index_gamma_operating_point), results_D_10000.tpr(results_D_10000.index_gamma_operating_point), '.', 'MarkerSize',10, 'LineWidth',5),
title('ROC', 'Interpreter', 'Latex')
xlabel('FPR', 'Interpreter', 'Latex')
ylabel('TPR', 'Interpreter', 'Latex')
legend(['ROC 100'], ['Point Empirical Pe 100'], ['Point Theoretical Pe 100'], ['ROC 1k'], ['Point Empirical Pe 1k'], ['Point Theoretical Pe 1k'], ['ROC 10k'], ['Point Empirical Pe 10k'], ['Point Theoretical Pe 10k'],'Interpreter', 'Latex')
grid on,

% Plot Probability of error
f = figure(2);
f.Position = [100, 100, 8e2, 5e2]; clf,
gamma_vector = linspace(0, 1e2, N_gamma);
semilogx(gamma_vector, log10(results_D_100.p_error))
hold on,
plot(gamma_vector(results_D_100.index_min_p_error), log10(results_D_100.p_error(results_D_100.index_min_p_error)), 'x', 'MarkerSize',10, 'LineWidth',5),
hold on,
plot(gamma_vector(results_D_100.index_gamma_operating_point), log10(results_D_100.p_error(results_D_100.index_gamma_operating_point)), '.', 'MarkerSize',10, 'LineWidth',5),
hold on,
semilogx(gamma_vector, log10(results_D_1000.p_error))
hold on,
plot(gamma_vector(results_D_1000.index_min_p_error), log10(results_D_1000.p_error(results_D_1000.index_min_p_error)), 'x', 'MarkerSize',10, 'LineWidth',5),
hold on,
plot(gamma_vector(results_D_1000.index_gamma_operating_point), log10(results_D_1000.p_error(results_D_1000.index_gamma_operating_point)), '.', 'MarkerSize',10, 'LineWidth',5),
hold on,
semilogx(gamma_vector, log10(results_D_10000.p_error))
hold on,
plot(gamma_vector(results_D_10000.index_min_p_error), log10(results_D_10000.p_error(results_D_10000.index_min_p_error)), 'x', 'MarkerSize',10, 'LineWidth',5),
hold on,
plot(gamma_vector(results_D_10000.index_gamma_operating_point), log10(results_D_10000.p_error(results_D_10000.index_gamma_operating_point)), '.', 'MarkerSize',10, 'LineWidth',5),
hold on,
title('P(error)', 'Interpreter', 'Latex')
ylabel('P(error) (log10)','Interpreter', 'Latex')
xlabel('gamma','Interpreter', 'Latex')
grid on,
legend(['Pe 100'], ['Empirical min Pe 100'], ['Theoretical Pe 100'], ['Pe 1k'], ['Empirical min Pe 1k'], ['Theoretical Pe 1k'], ['Pe 10k'], ['Empirical min Pe 10k'], ['Theoretical Pe 10k'],'Interpreter', 'Latex')
grid on,
%% Part 3 (20%)
clc
clear all
% Training set
filename = 'results_part_2_D_1000_train.mat' % change this 
training = load('D_1000_train.mat'); % change this to load a different training set
training.samples = training.data;
training.labels = training.labels;

% Validation set
validation = load('D_20K_validate.mat'); % change this to load a different training set
validation.samples = validation.data;
validation.labels = validation.labels;

% Class priors estimation (with the labels)
class_priors(2) = sum(training.labels)/size(training.samples,2);
class_priors(1) = 1 - class_priors(2);

% samples change depending on which dataset we are training
x = training.samples;
N = size(training.samples,2);
labels = training.labels;
for model_type = 1:2
    if model_type == 1 % Logistic Linear Model
        disp('Results for Logistic Linear Model are displayed')
        z = [ones(1,N); x];
        z_val = [ones(1,20000); validation.samples];
    else
        disp('Results for Logistic Quadratic Polynomial Model are displayed')
        z = [ones(1,N); x; x(1,:)   .*x(1,:); x(1,:).*x(2,:); x(2,:).*x(2,:)];
        z_val = [ones(1,20000); validation.samples; validation.samples(1,:).*validation.samples(1,:); validation.samples(1,:).*validation.samples(2,:);validation.samples(2,:).*validation.samples(2,:)];
    end
    w0 = zeros(size(z,1),1);
    cost = @(w)(-1/N)*sum(labels.*log(1./(1 + exp(-w'*z))) + (1-labels).*log(1 - 1./(1 + exp(-w'*z))));
    [w_hat, cost_min] = fminsearch(cost, w0);
    
    % Validation
    objective_function = round(1./(1 + exp(-w_hat'*z_val)))';
    failures_class_0 = length(find(objective_function==0 & validation.labels'==1))/length(find(validation.labels==1));
    failures_class_1 = length(find(objective_function==1 & validation.labels'==0))/length(find(validation.labels==0));
    disp('computed probability of error is')
    pe = failures_class_0*class_priors(1) + failures_class_1*class_priors(2);
    pe
end

