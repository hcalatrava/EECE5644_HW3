function pe_min = plot_ROC_Pe(N_gamma, likelihood_0, likelihood_1, labels, samples, class_priors, filename)

gamma_vector = linspace(0, 1e2, N_gamma);
for i = 1:length(gamma_vector)
    gamma_i = gamma_vector(i);
    classification_results = likelihood_1 > gamma_i*likelihood_0;
    confusion_matrix = confusionmat(labels, classification_results);
    % Calculate TPR
    true_positive = confusion_matrix(1,1);
    false_negative = confusion_matrix(1,2);
    tpr(i) = true_positive/(true_positive + false_negative);
    % Calculate FPR
    false_positive = confusion_matrix(2,1);
    true_negative = confusion_matrix(2,2);
    fpr(i) = false_positive / (false_positive + true_negative);
    % Probability of error Pe
    p_error(i) = (false_positive + false_negative)/size(samples,2);
end

% Calculate minimum achievable Pe
[min_p_error, index_min_p_error] = min(p_error);
gamma_best = gamma_vector(index_min_p_error);

% Calculate Pe operating point classifier
gamma_operating_point = find(gamma_vector>=class_priors(1)/class_priors(2));
index_gamma_operating_point = gamma_operating_point(1);

disp('empirical min pe')
disp(min_p_error)
disp('theoretical min pe')
disp(p_error(index_gamma_operating_point))
disp('empirical threshold')
disp(gamma_best)

% Plot Probability of Error (Pe)
f = figure(4);
f.Position = [100, 100, 8e2, 5e2]; clf,
semilogx(gamma_vector, log10(p_error))
hold on,
plot(gamma_vector(index_min_p_error), log10(p_error(index_min_p_error)), 'x', 'MarkerSize',10, 'LineWidth',5),
plot(gamma_vector(index_gamma_operating_point), log10(p_error(index_gamma_operating_point)), '.', 'MarkerSize',10, 'LineWidth',5),
title('P(error)', 'Interpreter', 'Latex')
ylabel('P(error) (log10)','Interpreter', 'Latex')
xlabel('gamma','Interpreter', 'Latex')
legend(['Pe'], ['Empirical min Pe'], ['Theoretical Pe'], 'Interpreter', 'Latex')
grid on,

% Plot ROC curve
f = figure(2);
f.Position = [100, 100, 8e2, 5e2]; clf,
plot(fpr, tpr)
hold on,
plot(fpr(index_min_p_error), tpr(index_min_p_error), 'x', 'MarkerSize',10, 'LineWidth',5),
plot(fpr(index_gamma_operating_point), tpr(index_gamma_operating_point), '.', 'MarkerSize',10, 'LineWidth',5),
title('ROC', 'Interpreter', 'Latex')
xlabel('FPR', 'Interpreter', 'Latex')
ylabel('TPR', 'Interpreter', 'Latex')
legend(['ROC'], ['Empirical min Pe point'], ['Classifier Operating Point (Theoretical)'], 'Interpreter', 'Latex')
grid on,

% Return variables
pe_min = min_p_error;

save(filename, 'fpr','tpr','index_min_p_error', "index_gamma_operating_point", 'p_error')