function range = get_range(pos_vehicle, pos_landmark, sigma_i)

nonnegative_condition = 0;
while nonnegative_condition == 0
    range = norm(pos_vehicle - pos_landmark) + randn(1)*sigma_i;
    if range > 0
        nonnegative_condition = 1;
    end
end