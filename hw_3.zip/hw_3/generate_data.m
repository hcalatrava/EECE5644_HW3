function generate_data(N, class_priors, gmm_priors, mu_0, C_0, mu_1, C_1, filename)

data = zeros(2,N);
labels = (rand(1,N) >= class_priors(1)); % 1s correspond to class 1 and 0s to class 0
% Loop through classes
for class = 0:1
    index_class = find(labels==class);
    N_class = length(index_class);
    if class == 0
        gmm_data = zeros(2,N_class);
        gmm_labels = (rand(1,N_class) >= gmm_priors(1)) + 1; % 1s corresponds to GMM component 1 and 2s to GMM component 2
        for component = 1:2
            index_component = find(gmm_labels==component);
            N_component = length(index_component);
            gmm_data(:, index_component) = mvnrnd(mu_0(:,component),C_0(:,:,component),N_component)';
        end
        data(:, index_class) = gmm_data;
    else % elseif class == 1
        data(:,index_class) = mvnrnd(mu_1, C_1, N_class)';
    end
end
save(filename,'data','labels','gmm_labels','-mat');
disp([filename, ' has been saved']);
