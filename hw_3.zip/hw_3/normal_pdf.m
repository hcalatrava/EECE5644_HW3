function [likelihood_0, likelihood_1] = get_likelihood(samples, mu_0, C_0, mu_1, C_1, gmm_priors)
% For each data point (or sample), we get the likelihood value for both
% class assumptions

% It is assumed that data of class 0 follows a GMM distribution with 2
% components (mean mu_0, covariance matrix C_0), while data of class 1 follows a Gaussian distribution 
for data_point = 1:size(samples,2)
    likelihood_0(data_point) = gmm_priors(1)*mvnpdf(samples(:,data_point), mu_0(:,1), C_0(:,:,1)) + gmm_priors(2)*mvnpdf(samples(:,data_point), mu_0(:,2), C_0(:,:,2));
    likelihood_1(data_point) = mvnpdf(samples(:,data_point), mu_1, C_1); % value of class 1 likelihood for sample in the loop

    % Classification result
    % classification_results(data_point) is the value given by the bayes
    % classifier (if 1, it belongs to class 1; if 0, it belongs to class 0)
    %classification_results(data_point) = likelihood_1(data_point)/likelihood_0(data_point) > class_priors(1)/class_priors(2);
end
