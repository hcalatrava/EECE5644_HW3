%% Init program
clear all
close all
clc
rng('default')

%% Generate scenario

% True vehicle position
s_t = [0.5 0.5]'; % we define position vectors as column vectors (like in the exercise)

% Landmark coordinates (hardcoded)
landmark.pos{1} = [1 0]';
landmark.pos{2} = [1 -1; 0 0];
landmark.pos{3} = [1 -0.5 -0.5; 0 0.866 -0.866];
landmark.pos{4}  = [1 0 -1 0; 0 1 0 -1];
landmark.num = 4; % number of landmarks in the scenario

% Standard deviation values
sigma_i = 0.3;
    sigma_x = 0.25; % sigma_x and sigma_y are related to the prior confidence
sigma_y = 0.25;
C = [sigma_x^2 0; 0 sigma_y^2];

% Plot Scenario
f = figure(1);
f.Position = [100, 100, 8e2, 5e2]; clf,
for experiment_i = 1:landmark.num % Loop landmarks (one experiment per number of landmarks)
    subplot(2,2,experiment_i);
    viscircles([0 0], 1); % plot unit circle (R=1) centered at the origin
    hold on,
    plot(s_t(1), s_t(2), 'x', 'MarkerSize',10, 'LineWidth',5, 'DisplayName','Vehicle Position')
    hold on,
    for landmark_i = 1:size(landmark.pos{experiment_i},2) % Again, loop landmarks because we want to plot a marker at the position of each landmark
        plot(landmark.pos{experiment_i}(1,landmark_i), landmark.pos{experiment_i}(2,landmark_i), 'o', 'MarkerSize',10, 'LineWidth',5, 'DisplayName', ['Landmark ', num2str(landmark_i), ' Position'])
        hold on,
    end
    grid on,
    title([num2str(experiment_i), ' landmarks'])
    xlabel('X coord [m]')
    ylabel('Y coord [m]')
end
legend show
legend('location','southoutside','Orientation','horizontal','Box','off', 'Position',[0.45 0.93 0.15 0.0869])


%% MAP estimation equilevel contours
clc
rng(1)
% Plot Scenario
f = figure(1);
mesh_size = 1e3;
mesh_range = linspace(-2,2,mesh_size);
[mesh_x, mesh_y] = ndgrid(mesh_range, mesh_range);
f.Position = [100, 100, 8e2, 5e2]; clf,
for experiment_i = 1:landmark.num % Loop landmarks (one experiment per number of landmarks)
    subplot(2,2,experiment_i);
    for landmark_i = 1:size(landmark.pos{experiment_i},2) % Again, loop landmarks because we want to plot a marker at the position of each landmark
        % Generate K nonnegative range measurements
        range{experiment_i}(landmark_i) = get_range(s_t, landmark.pos{experiment_i}(:,landmark_i), sigma_i);
    end
    % We evaluate the objective function obtaind with the MAP estimator at
    % each point of the meshgrid defined by horizontal and vertical
    % coordinates from -2 and 2
    for idx_i = linspace(1,mesh_size,mesh_size)
        for idx_j = linspace(1,mesh_size,mesh_size)
            x = mesh_x(idx_i, idx_j);
            y = mesh_y(idx_i, idx_j);
            sum_likelihood = 0;
             %objective_function = @(x,y) symsum((range{experiment_i}(k) - norm([x,y]' - landmark.pos{experiment_i}(:,k)))^2, k, 1, size(landmark.pos{experiment_i},2)) + [x,y]*inv(C)*[x,y]';
            for k = 1:size(landmark.pos{experiment_i},2) % Again, loop landmarks because we want to plot a marker at the position of each landmark
                sum_likelihood = sum_likelihood + ((range{experiment_i}(k) - norm([x,y]' - landmark.pos{experiment_i}(:,k)))/sigma_i)^2;
            end
            MAP_contour(idx_i,idx_j) = sum_likelihood + [x,y]*inv(C)*[x,y]';
        end
    end
    disp(min(min(MAP_contour)))
    contour(mesh_x,mesh_y,MAP_contour,'ShowText', 'on', 'LevelList',[100, 80, 70, 60, 50, 30, 20, 10, 5])
    grid on,
    hold on,
    viscircles([0 0], 1); % plot unit circle (R=1) centered at the origin
    plot(s_t(1), s_t(2), 'x', 'MarkerSize',10, 'LineWidth',5, 'DisplayName','Vehicle Position')
    hold on,
    for landmark_i = 1:size(landmark.pos{experiment_i},2) % Again, loop landmarks because we want to plot a marker at the position of each landmark
        plot(landmark.pos{experiment_i}(1,landmark_i), landmark.pos{experiment_i}(2,landmark_i), 'o', 'MarkerSize',10, 'LineWidth',5, 'DisplayName', ['Landmark ', num2str(landmark_i), ' Position'])
        hold on,
        % Generate K nonnegative range measurements
        %range{experiment_i}(landmark_i) = get_range(s_t, landmark.pos{experiment_i}(:,landmark_i), sigma_i);
    end
    hold on,
    title([num2str(experiment_i), ' landmarks'])
    xlabel('X coord [m]')
    ylabel('Y coord [m]')
end
legend show
legend('location','southoutside','Orientation','horizontal','Box','off', 'Position',[0.45 0.93 0.15 0.0869])

%% MAP estimation equilevel contours (trying to avoid for loops)
% clc
% % Plot Scenario
% f = figure(1);
% mesh_range = linspace(-2,2,10);
% [mesh_x, mesh_y] = ndgrid(mesh_range, mesh_range);
% f.Position = [100, 100, 8e2, 5e2]; clf,
% for experiment_i = 1:landmark.num % Loop landmarks (one experiment per number of landmarks)
%     subplot(2,2,experiment_i);
%     for landmark_i = 1:size(landmark.pos{experiment_i},2) % Again, loop landmarks because we want to plot a marker at the position of each landmark
%         % Generate K nonnegative range measurements
%         range{experiment_i}(landmark_i) = get_range(s_t, landmark.pos{experiment_i}(:,landmark_i), sigma_i);
%     end
%     % We evaluate the objective function obtaind with the MAP estimator at
%     % each point of the meshgrid defined by horizontal and vertical
%     % coordinates from -2 and 2
%     %objective_function = @(x,y) symsum((range{experiment_i}(k) - norm([x,y]' - landmark.pos{experiment_i}(:,k)))^2, k, 1, size(landmark.pos{experiment_i},2)) + [x,y]*inv(C)*[x,y]';
%     ranges_experiment = range{experiment_i};
%     syms k 
%     objective_function = @(x,y) sum(((range{experiment_i} - norm([x,y]' - landmark.pos{experiment_i}))/sigma_i)^2) + [x,y]*inv(C)*[x,y]';
%     MAP_contour = arrayfun(objective_function,mesh_x, mesh_y);
%     %MAP_contour = objective_function(mesh_x, mesh_2y);
%     contour(mesh_x,mesh_y,MAP_contour,levels=10)
%     grid on,
%     hold on,
%     viscircles([0 0], 1); % plot unit circle (R=1) centered at the origin
%     plot(s_t(1), s_t(2), 'x', 'MarkerSize',10, 'LineWidth',5, 'DisplayName','Vehicle Position')
%     hold on,
%     for landmark_i = 1:size(landmark.pos{experiment_i},2) % Again, loop landmarks because we want to plot a marker at the position of each landmark
%         plot(landmark.pos{experiment_i}(1,landmark_i), landmark.pos{experiment_i}(2,landmark_i), 'o', 'MarkerSize',10, 'LineWidth',5, 'DisplayName', ['Landmark ', num2str(landmark_i), ' Position'])
%         hold on,
%         % Generate K nonnegative range measurements
%         %range{experiment_i}(landmark_i) = get_range(s_t, landmark.pos{experiment_i}(:,landmark_i), sigma_i);
%     end
%     hold on,
%     title([num2str(experiment_i), ' landmarks'])
%     xlabel('X coord [m]')
%     ylabel('Y coord [m]')
% end
% legend show
% legend('location','southoutside','Orientation','horizontal','Box','off', 'Position',[0.45 0.93 0.15 0.0869])
% 
% 

